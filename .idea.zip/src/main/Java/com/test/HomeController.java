package com.test;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
    @GetMapping("/home")
    public String goHome(){
        System.out.println("in Home Controller");
        return "index";
    }
    @GetMapping("/goToSearch")
    public String goToSearch(){
        System.out.println("in search Controller");
        return "search";
    }
    @GetMapping("/goToLogin")
    public String goToLogin(){
        System.out.println("in login Controller");
        return "login";
    }
    @GetMapping("/goToRegister")
    public String goToRegister(){
        System.out.println("in Register Controller");
        return "register";
    }
}
